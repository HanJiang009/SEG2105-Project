package com.example.han.choremanager; /**
 * Created by 91373 on 2017/11/23.
 */
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;


import com.example.han.choremanager.R;

public class Tab2fragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab2fragment, container, false);

        String[] choreList = {"Walk Dog", "Do the Dishes", "Clean Room", "Make Bed", "Take Trash Out"};

        ListView listView = (ListView) rootView.findViewById(R.id.list);

        ChoreCustomAdapter adapter = new ChoreCustomAdapter(this.getContext(),choreList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
//Here we insert some code to do something!
            }
        });

        return rootView;
    }



}

