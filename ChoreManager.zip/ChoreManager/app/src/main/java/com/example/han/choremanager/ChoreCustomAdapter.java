package com.example.han.choremanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by 91373 on 2017/11/24.
 */

public class ChoreCustomAdapter extends ArrayAdapter{
    private final Context context;
    private final String[] myChores;

    public ChoreCustomAdapter(Context context, String[] choreList) {
        super(context, R.layout.chore_item_layout, choreList);
        this.context = context;
        this.myChores = choreList;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.chore_item_layout, parent, false);

        TextView choreNameTextField = (TextView) rowView.findViewById(R.id.ChoreName);
        TextView choreDescriptionTextField = (TextView) rowView.findViewById(R.id.Description);
        ImageView choreImage = (ImageView) rowView.findViewById(R.id.icon);

        choreNameTextField.setText(myChores[position]);
        choreDescriptionTextField.setText(myChores[position] + " is a chore!");

        return rowView;
    }
}
