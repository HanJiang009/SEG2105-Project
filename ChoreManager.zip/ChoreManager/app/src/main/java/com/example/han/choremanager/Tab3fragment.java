package com.example.han.choremanager; /**
 * Created by 91373 on 2017/11/23.
 */
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.han.choremanager.R;

public class Tab3fragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab3fragment, container, false);

        String[] userList = {"Dad", "Mom", "Son", "Daughter"};
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        UserCustomAdapter adapter = new UserCustomAdapter(this.getContext(),userList);
        listView.setAdapter(adapter);

        return rootView;
    }
}

