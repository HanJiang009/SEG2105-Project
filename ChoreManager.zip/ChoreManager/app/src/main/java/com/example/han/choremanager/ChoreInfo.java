package com.example.han.choremanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ChoreInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chore_info);
    }
}
